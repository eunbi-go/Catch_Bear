#include "pch.h"
#include "CorePch.h"

void HelloWorld()
{
	cout << "Hello Server!" << endl;
}